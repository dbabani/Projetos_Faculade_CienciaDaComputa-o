#pip install streamlit pyaudio

import streamlit as st  
from Componentes import NewConvesationButton
from Componentes import MicrophoneButton
from Componentes import SendButton
from Componentes import SideBAr
from pydub import AudioSegment
import base64
import requests
import io
import os
import wave
import pyaudio


def convert_wav_to_mp3(wav_filename, mp3_filename):
    AudioSegment.converter = "/opt/homebrew/bin/ffmpeg"
    sound = AudioSegment._from_safe_wav(wav_filename)
    sound.export(mp3_filename, format="mp3")
    return mp3_filename


FORMAT = pyaudio.paInt16  
CHANNELS = 1  
RATE = 16000 
CHUNK = 1024  

p = pyaudio.PyAudio()

def open_audio_stream():
    stream = p.open(format=FORMAT,
                    channels=CHANNELS,
                    rate=RATE,
                    input=True,
                    frames_per_buffer=CHUNK)
    return stream

if 'frames' not in st.session_state:
    st.session_state['frames'] = []  
if 'recording' not in st.session_state:
    st.session_state['recording'] = False  
if 'current_wave_file' not in st.session_state:
    st.session_state['current_wave_file'] = None  

def start_recording(stream):
    st.session_state['frames'] = []  
    st.session_state['recording'] = True
    while st.session_state['recording']:
        data = stream.read(CHUNK, exception_on_overflow=False)
        st.session_state['frames'].append(data)

def stop_recording(stream):
    st.session_state['recording'] = False
    stream.stop_stream()
    stream.close()

def clear_recording():
    st.session_state['frames'] = []
    if st.session_state['current_wave_file'] and os.path.exists(st.session_state['current_wave_file']):
        os.remove(st.session_state['current_wave_file'])

def save_recording():
    wave_output = io.BytesIO()
    wf = wave.open(wave_output, 'wb')
    wf.setnchannels(CHANNELS)
    wf.setsampwidth(p.get_sample_size(FORMAT))
    wf.setframerate(RATE)
    wf.writeframes(b''.join(st.session_state['frames']))
    wf.close()

    wave_file_path = 'temp_audio.wav'
    if st.session_state['current_wave_file'] and os.path.exists(st.session_state['current_wave_file']):
        os.remove(st.session_state['current_wave_file'])
    with open(wave_file_path, 'wb') as f:
        f.write(wave_output.getvalue())
    st.session_state['current_wave_file'] = wave_file_path
    return wave_file_path


NewConvesationButton.on_click()
st.title('Converse com o psicologo Caio')
stream = None  


col1, col2, col3 = st.columns([1, 1, 1])

with col2:
    if MicrophoneButton.MicrophoneButton():
        st.info("Gravando o audio")
        if not stream:
            stream = open_audio_stream()
        start_recording(stream)     
with col3:               
    if SendButton.SendButton():   
        st.info("Audio em processamento...")
        file_path = save_recording()
        mp3_file = convert_wav_to_mp3(file_path,"temp_audio.mp3")
        file = {'file': ('temp_audio.mp3', open(mp3_file, 'rb'))}
        response = requests.post("http://localhost:8000/talk", files=file)
        if response.status_code == 200:
            audio_response = requests.get("http://localhost:8000/getAudio")
            if audio_response.status_code == 200:
                st.audio(audio_response.content, format='audio/mp3')
            
                


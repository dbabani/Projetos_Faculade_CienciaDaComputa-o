import streamlit as st
import requests
from st_audiorec import st_audiorec
from pydub import AudioSegment
import wave
import base64
import streamlit.components.v1 as components
import streamlit as st
from streamlit_extras.stylable_container import stylable_container 

def on_click():
   with stylable_container(
            "New",
            css_styles="""
                button {
                position: fixed;
                top: 50px;
                right: 20px;
                width: 65px;
                height: 40px;
                background-color: green;
                color: #fff;
                border: none;
                border-radius: 50%;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 24px;
                cursor: pointer;
}""",
        ):
    New_ConversationButton = st.button("New")
    if New_ConversationButton:
        st.success("Nova conversa criada com sucesso!!")

        Clear_Histroy_response = requests.get("http://localhost:8000/clear")
        if  Clear_Histroy_response.status_code == 200:
            data =  Clear_Histroy_response.json()
            print(data["message"])
        else:
            print("Erro ao limpar os dados", Clear_Histroy_response.status_code)


        RemoveFileResponse = requests.delete("http://localhost:8000/delete-file")
        if RemoveFileResponse.status_code == 204:
            data = RemoveFileResponse.json()
            print(data["message"])

        else:
            print("Não foi possivel remover o arquivo")
        
import streamlit as st
from streamlit_extras.stylable_container import stylable_container




def SendButton():
    Send_button= """
        button{
            background: green;
            color: white;
            border-style: outset;
            border-color: #0066A2;
            height: 75px;
            width: 125px;
            font: bold15px arial,sans-serif;
            text-shadow: none;
        }
        """
    with stylable_container("S", css_styles=Send_button):
        SendButton = st.button(" Parar e Enviar")
        return SendButton




    
         
import streamlit as st
from streamlit_extras.stylable_container import stylable_container
import base64

def svg_to_base64(svg_file_path):
    # Lendo o conteúdo do arquivo SVG
    with open(svg_file_path, 'r') as file:
        svg_string = file.read()

    # Convertendo o SVG para base64
    svg_bytes = svg_string.encode('utf-8')
    svg_base64 = base64.b64encode(svg_bytes).decode('utf-8')
    return svg_base64



def MicrophoneButton():
    svg_base64 = svg_to_base64("./assets/microphone.svg")
    green_button= """
        button{
            background-color:gray;
            border: none;
            border-radius: 50%;
            width: 100px;
            height: 100px;
            background-image: url('data:image/svg+xml;base64,""" + svg_base64 + """'); 
            background-repeat: no-repeat;
            background-position: center;
            background-size: 60%;
            cursor: pointer;
        }
        """
    with stylable_container("greenMicButton", css_styles=green_button):
        MicrophoneButton = st.button(" ")
        return MicrophoneButton




    
         
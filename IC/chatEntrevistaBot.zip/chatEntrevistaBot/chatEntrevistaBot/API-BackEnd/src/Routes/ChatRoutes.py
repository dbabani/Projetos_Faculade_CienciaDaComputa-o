from Controllers import ChatController 
from fastapi import APIRouter, FastAPI,UploadFile

router = APIRouter()

@router.post("/talk")
async def post_audio(file:UploadFile):
    return await ChatController.ChatController.post_audio(file)

@router.get("/getAudio")
async def getAudio():
    return  await ChatController.ChatController.get_audio()

@router.get("/clear")
async def clear_history():
    return await ChatController.ChatController.clear_history()

@router.delete("/delete-file")
async def delete_file():
    return await ChatController.ChatController.delete_file()
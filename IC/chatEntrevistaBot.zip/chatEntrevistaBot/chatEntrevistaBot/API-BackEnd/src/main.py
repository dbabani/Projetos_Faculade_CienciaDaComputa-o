#Para executar utilize o comando uvicorn main:app --reload
#abra o arquivo index.html
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from Routes import ChatRoutes


# Inicializando uma instancia do FastAPI
app = FastAPI()

origins = [
    "http://localhost:3000",  # Ajuste para a porta e o host do seu frontend
    "http://localhost:8000",  # Permitir solicitações do próprio servidor
    "null"  # Para permitir solicitações de file:// ou quando não há 'origin'
]


# CORS - Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins, 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Rotas da aplicação
app.include_router(ChatRoutes.router)

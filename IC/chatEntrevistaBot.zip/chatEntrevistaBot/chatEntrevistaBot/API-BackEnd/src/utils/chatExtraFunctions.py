import os
import json
from dotenv import load_dotenv
import openai

# Carregando variáveis de ambiente
load_dotenv()

# Configurando a chave de API e a organização do OpenAI
openai.api_key = os.getenv("OPEN_AI_KEY")
openai.organization = os.getenv("OPEN_AI_ORG")

def transcribe_audio(file_location):
    with open(file_location, "rb") as audio_file:
        transcript = openai.audio.transcriptions.create(model="whisper-1", file=audio_file, response_format='text')
        print(transcript)
        return transcript

# Função para obter a resposta do chat com base na mensagem do usuário
def get_chat_response(user_message):
    messages = load_messages()
    messages.append({"role": "user", "content": user_message})
    gpt_response = openai.chat.completions.create(model="gpt-4-1106-preview", messages=messages,temperature=0.0)
    parsed_gpt_response = gpt_response.choices[0].message.content
    save_messages(user_message, parsed_gpt_response)
    return parsed_gpt_response

# Função para carregar mensagens anteriores do histórico
def load_messages():
    messages = []
    file = './database/database.json'
    empty = os.stat(file).st_size == 0
    if not empty:
        with open(file, encoding='utf-8') as db_file:
            data = json.load(db_file)
            messages.extend(data)
    else:
        messages.append({
            "role": "system",
            "content":"Você é um psicólogo realizando uma entrevista de avaliação neuropsicológica. Faça perguntas específicas e curtas para o paciente que avalie características cognitivas. Seu nome é Caio e você fala somente portugues brasileiro. Pergunte o nome do usuário sempre no início. Mantenha suas respostas por volta de 30 palavras e seja engraçado às vezes"
        })
    return messages

# Função para salvar as mensagens no histórico
def save_messages(user_message, gpt_response):
    file = "./database/database.json"
    messages = load_messages()
    messages.append({"role": "user", "content": user_message})
    messages.append({"role": "assistant", "content": gpt_response})
    with open(file, 'w', encoding='utf-8') as f:
        json.dump(messages, f, ensure_ascii=False)

# Função para converter o texto em fala
def text_to_speech(text):
    response = openai.audio.speech.create(
        model="tts-1",
        voice="echo",
        input=text,
    )
    return response.stream_to_file("../Output/output.mp3")

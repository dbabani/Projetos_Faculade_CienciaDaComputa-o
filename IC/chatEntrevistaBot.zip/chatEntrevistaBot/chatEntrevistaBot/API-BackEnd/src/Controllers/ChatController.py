from fastapi import Response, UploadFile
import os
from fastapi.responses import StreamingResponse
from utils import chatExtraFunctions


class ChatController:

    #Criar uma conversa
    async def post_audio(file: UploadFile):
      file_location = f"../Output/output.mp3"
      with open(file_location, "wb") as f:
        contents = await file.read()
        f.write(contents)
    
    # Transcrevendo o áudio para texto
      user_message = chatExtraFunctions.transcribe_audio(file_location)
    # Obtendo a resposta do chat baseado no texto transcrito
      chat_response = chatExtraFunctions.get_chat_response(user_message)
    # Convertendo a resposta do chat em áudio
      chatExtraFunctions.text_to_speech(chat_response)

    # Função geradora para streaming do arquivo de áudio
      def iterfile():
       with open('../Output/output.mp3', 'rb') as f:
        yield from f  # Isso irá transmitir o arquivo de áudio

        return StreamingResponse(iterfile(),media_type="audio/mp3")

    async def get_audio():
        file_location = "../Output/output.mp3"
        with open(file_location, "rb") as f:
            audio_data = f.read()
        return StreamingResponse(iter([audio_data]), media_type="audio/mp3")



    
    #Deletar o historico de conversa
    async def clear_history():
     file = './database/database.json'
     open(file, 'w')
     return {"message": "Chat history has been cleared"}
    
    #Deletar o arquivo de saida gerada.
    async def delete_file():
      try:
        os.remove("../Output/output.mp3")
        return {"message": "File deleted successfully"}
      except FileNotFoundError:
        return {"message": "File not found"}
      except Exception as e:
        return {"message": f"Error deleting file: {e}"}
      
    

    











    



